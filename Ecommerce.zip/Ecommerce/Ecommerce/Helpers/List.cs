﻿namespace Ecommerce.Helpers
{
    internal class List
    {
    }
}