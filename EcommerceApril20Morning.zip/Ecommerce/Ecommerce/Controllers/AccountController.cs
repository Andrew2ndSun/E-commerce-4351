﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc; 
using Microsoft.AspNetCore.Identity;
using Ecommerce.Models;
using Ecommerce.Data;
using Ecommerce.Models.ViewModel;

namespace Ecommerce.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<EcommerceUser> userManager;
        private readonly SignInManager<EcommerceUser> signInManager;
        public AccountController(UserManager<EcommerceUser> userManager,
           SignInManager<EcommerceUser> signInManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new EcommerceUser
                {
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    StreetAddress = model.StreetAddress,
                    City = model.City,
                    State = model.State,
                    Zipcode = model.Zipcode,
                    PhoneNumber = model.PhoneNumber,
                    UserName = model.Email,
                    Email = model.Email,
                    EmailConfirmed = true,
                    level=1,
                };
                var result = await userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    await signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View();
        }
        [HttpGet]
        public IActionResult Login(string returnUrl = "")
        {
            var model = new LoginViewModel { ReturnUrl = returnUrl }; 
            return View(model);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            { 
                var result = await signInManager.PasswordSignInAsync(model.Username,
                   model.Password, model.RememberMe, false);

                if (result.Succeeded)
                {
                    if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                    {
                        return Redirect(model.ReturnUrl);
                    }
                    else
                    {
                        
                        EcommerceUser user = await userManager.FindByNameAsync(model.Username);
                        if(user.level==0) return RedirectToAction("Index", "Products");
                        else  return RedirectToAction("Index", "Home");
                        
                    
                    }
                } 
            }
            ModelState.AddModelError("", "Invalid login attempt");
            
            return View(model);
        }
    }
}