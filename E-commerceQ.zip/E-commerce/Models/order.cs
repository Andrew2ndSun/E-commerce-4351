﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace E_commerce.Models
{
    public class order
    {
        public int orderID { get; set; }
        public int ID  { get; set; }
        public string productInOrder { get; set; }
        public string shippingaddress { get; set; }
    }
}
